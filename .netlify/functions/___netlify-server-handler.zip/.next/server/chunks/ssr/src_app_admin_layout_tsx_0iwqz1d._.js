module.exports=[36102,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("div",{className:"min-h-screen bg-ivory",children:a})}])},44067,a=>{a.n(a.i(36102))}];

//# sourceMappingURL=src_app_admin_layout_tsx_0iwqz1d._.js.map