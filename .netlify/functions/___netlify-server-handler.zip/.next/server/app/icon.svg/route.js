var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.svg/route.js")
R.c("server/chunks/[root-of-the-server]__04dzkv1._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_icon_svg_route_actions_1r2h_ub.js")
R.m(61233)
module.exports=R.m(61233).exports
