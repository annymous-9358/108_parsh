globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/HtZF99ZqlRpC-6mlTG7s2/_buildManifest.js",
    "static/HtZF99ZqlRpC-6mlTG7s2/_ssgManifest.js",
    "static/HtZF99ZqlRpC-6mlTG7s2/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/40e0f9pufs6g4.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/1upe53-127sm4.js",
    "static/chunks/2wxm6mdam4qg6.js",
    "static/chunks/turbopack-3omx3o53ej18b.js"
  ]
};
